package org.apache.ignite.examples.datagrid.oracle;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.IgniteException;
import org.apache.ignite.Ignition;
import org.apache.ignite.cache.query.QueryCursor;
import org.apache.ignite.cache.query.SqlFieldsQuery;
import org.apache.ignite.examples.model.Person;
import org.apache.ignite.examples.model.Transaction;

public class TransactionStoreExample {
    public static void main(String[] args) throws IgniteException {
        //Ignition.setClientMode(true);
 
        try (Ignite ignite = Ignition.start("config/transaction-config.xml")) {
            try (IgniteCache<Long, Transaction> cache = ignite.getOrCreateCache("transactionCache")) {
                // Load cache with data from the database.
            	SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
                
            	System.out.println(sdfDate.format(new Date()));
                
                cache.loadCache(null);
                
                System.out.println(sdfDate.format(new Date())); 
                
                // Execute query on cache.
                QueryCursor<List<?>> cursor = cache.query(new SqlFieldsQuery("select id, transactionAmount from Transaction where groupCode = '419194' and scheme = 'MasterCard' and transactionDate > '2015-01-01 00:00:00' and transactionDate < '2018-01-01 00:00:00' and mid in ('45622746','45622246','45692346','45700736','45693736','45498366','45622086','45700656','45623136','45497636')  order by transactionDate asc limit 100 offset 100"));
 
                System.out.println(sdfDate.format(new Date())); 
                
                System.out.println(cursor.getAll());

                System.out.println(sdfDate.format(new Date()));
            }
        }
    }
}