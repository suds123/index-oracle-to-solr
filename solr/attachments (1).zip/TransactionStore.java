package org.apache.ignite.examples.datagrid.oracle;

import java.sql.Connection;
import org.apache.ignite.examples.model.Transaction;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Map;

import javax.cache.Cache.Entry;
import javax.cache.integration.CacheLoaderException;
import javax.cache.integration.CacheWriterException;
import javax.sql.DataSource;

import org.apache.ignite.cache.store.CacheStore;
import org.apache.ignite.lang.IgniteBiInClosure;
import org.apache.ignite.resources.SpringResource;
import org.jetbrains.annotations.Nullable;

public class TransactionStore implements CacheStore<Long, Transaction> {
	
	@SpringResource(resourceName = "dataSource")
    private DataSource dataSource;
	
    // This method is called whenever IgniteCache.loadCache() method is called.
    @Override
    public void loadCache(IgniteBiInClosure<Long, Transaction> clo, @Nullable Object... objects) throws CacheLoaderException {
        System.out.println(">> Loading cache from store...");

        try (Connection conn = dataSource.getConnection()) {
            try (PreparedStatement st = conn.prepareStatement("select rownum, f.* from fact_transactions f where substr(mid,1,1) = '4' and rownum < 1000000")) {
                try (ResultSet rs = st.executeQuery()) {
                    while (rs.next()) {
                    	Transaction transaction = new Transaction(rs.getLong(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),rs.getString(6),rs.getDate(7),rs.getDate(8) ,rs.getString(9) ,rs.getString(10) ,rs.getTimestamp(11) ,rs.getString(12) ,rs.getString(13) ,rs.getString(14) ,rs.getString(15) , rs.getString(16) ,rs.getDouble(17) ,rs.getString(18) ,rs.getDouble(19) ,rs.getString(20) ,rs.getString(21) ,rs.getString(22) ,rs.getString(23) ,rs.getString(24) ,rs.getString(25) ,rs.getString(26) ,rs.getString(27) ,rs.getString(28),rs.getString(29));
                    	//System.out.println("<"+rs.getLong(1) + "> <" + rs.getString(2)+"> <"+ rs.getString(3)+"> <"+ rs.getString(4)+"> <"+ rs.getString(5)+"> <"+ rs.getString(6)+"> <"+ rs.getTimestamp(7));
                        clo.apply(transaction.getId(), transaction);
                    }
                }
            }
        }
        catch (SQLException e) {
            throw new CacheLoaderException("Failed to load values from cache store.", e);
        }
    }

    // This method is called whenever IgniteCache.get() method is called.
    @Override
    public Transaction load(Long key) throws CacheLoaderException {
        return null;
    }  
    
	@Override
	public Map<Long, Transaction> loadAll(Iterable<? extends Long> arg0) throws CacheLoaderException {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public void delete(Object arg0) throws CacheWriterException {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void deleteAll(Collection<?> arg0) throws CacheWriterException {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void write(Entry<? extends Long, ? extends Transaction> arg0) throws CacheWriterException {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void writeAll(Collection<Entry<? extends Long, ? extends Transaction>> arg0) throws CacheWriterException {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void sessionEnd(boolean arg0) throws CacheWriterException {
		// TODO Auto-generated method stub
		
	}

}

