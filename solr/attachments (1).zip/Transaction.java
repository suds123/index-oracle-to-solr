package org.apache.ignite.examples.model;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;

import org.apache.ignite.cache.query.annotations.QuerySqlField;
import org.apache.ignite.cache.query.annotations.QueryTextField;

public class Transaction implements Serializable {
	@QuerySqlField(index = true)
    public Long id;
    
	@QuerySqlField(index = true)
    public String mid;
    
    public String outletName;
    public String company;
    public String companyName;
    public String groupName;
    public Date tradingDate;
    public Date processingDate;
    public String cardNumber;
    public String cardExpiryDate;
    
    // 11th field
    @QuerySqlField(index = true)
    public Timestamp transactionDate;
    
    @QuerySqlField(index = true)
    public String originatorsTransactionRef;
    public String ticketNumber;
    public String transactionTypeName;
    public String transactionSourceName;
    public String receiptNumber;
    // 17th field
    public double settlementAmount;
    public String settlementCurrency;
    
    // 19th field
    @QuerySqlField(index = true)
    public double transactionAmount;
    
    @QuerySqlField(index = true)
    public String transactionCurrency;
    public String authCode;
    
    /** create LUCENE-based TEXT index for this field */
    @QueryTextField
    public String cardBrand;
    
    public String cardProductTypeName;
    public String cardProductTypeCode;
    
    @QuerySqlField(index = true)
    public String scheme;
    
    public String debitCredit;
    public String cardSequenceNo;
    public String acquiredProcessed;
    
    @QuerySqlField(index = true)
    public String groupCode;

    public Transaction(Long id,String mid, String outletName, String company, String companyName,String groupName,Date tradingDate,Date processingDate,String cardNumber,String cardExpiryDate,Timestamp transactionDate,String originatorsTransactionRef,String ticketNumber,String transactionTypeName,String transactionSourceName, String receiptNumber,double settlementAmount,String settlementCurrency,double transactionAmount,String transactionCurrency,String authCode,String cardBrand,String cardProductTypeName,String cardProductTypeCode,String scheme,String debitCredit,String cardSequenceNo,String acquiredProcessed,String groupCode) {
        this.id = id;
    	this.mid = mid;
        this.outletName = outletName;
        this.company = company;
        this.companyName = companyName;
        this.groupName = groupName;
        this.tradingDate = tradingDate;
        this.processingDate = processingDate;
        this.cardNumber = cardNumber;
        this.cardExpiryDate = cardExpiryDate;
        this.transactionDate = transactionDate;
        this.originatorsTransactionRef = originatorsTransactionRef;
        this.ticketNumber = ticketNumber;
        this.transactionTypeName = transactionTypeName;
        this.transactionSourceName = transactionSourceName;
        this.receiptNumber = receiptNumber;
        this.settlementAmount = settlementAmount;
        this.settlementCurrency = settlementCurrency;
        this.transactionAmount = transactionAmount;
        this.transactionCurrency = transactionCurrency;
        this.authCode = authCode;
        this.cardBrand = cardBrand;
        this.cardProductTypeName = cardProductTypeName;
        this.cardProductTypeCode = cardProductTypeCode;
        this.scheme = scheme;
        this.debitCredit = debitCredit;
        this.cardSequenceNo = cardSequenceNo;
        this.acquiredProcessed = acquiredProcessed;
        this.groupCode = groupCode;
    }
    
	public Long getId() {
		// TODO Auto-generated method stub
		return this.id;
	}
}
